# base_agent.py
# Clean version that prevents information leakage

import database_personal as database
import os

class BaseAgent:
    """Base agent class with leak-proof architecture."""

    def __init__(self, supabase, ai_model, agent_name=None):
        """Initialize the base agent with correct parameters."""
        self.supabase = supabase
        self.ai_model = ai_model
        self.agent_name = agent_name or self.__class__.__name__
        self.prompts = {}
        self.comprehensive_prompts = {}
        
    def load_comprehensive_prompts(self):
        """Loads all prompts relative to the project's structure."""
        try:
            prompts_dict = {}
            project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
            v1_dir = os.path.join(project_root, "prompts", "v1")
            
            if os.path.exists(v1_dir):
                for file_name in os.listdir(v1_dir):
                    if file_name.endswith('.md'):
                        prompt_name = file_name.replace('.md', '')
                        file_path = os.path.join(v1_dir, file_name)
                        with open(file_path, 'r', encoding='utf-8') as f:
                            prompts_dict[prompt_name] = f.read()
            else:
                print(f"WARNING: Prompts directory not found at {v1_dir}")

            self.comprehensive_prompts = {
                'core_system': self._build_base_system_prompt(prompts_dict)
            }
            return self.comprehensive_prompts
        except Exception as e:
            print(f"Error loading comprehensive prompts: {e}")
            return {}

    def _build_base_system_prompt(self, prompts_dict):
        """Builds the system prompt for the base agent."""
        core_identity = prompts_dict.get('00_core_identity', 'You are a helpful assistant.')
        # CRITICAL: Add leak prevention instructions
        leak_prevention = """
        
IMPORTANT: Your response must be ONLY user-friendly text. Never include:
        - Technical details, system information, or internal data
        - JSON structures, code blocks, or technical formatting
        - Action logs, debugging info, or system status
        - References to internal processes, agents, or system architecture
        
        Respond as a helpful assistant would in natural conversation.
        """
        return f"{core_identity}{leak_prevention}"
        
    async def process(self, user_input, context, routing_info=None):
        """Process user input and return a response."""
        raise NotImplementedError("Subclasses must implement this method")
    
    def _log_action(self, user_id, action_type, entity_type, entity_id=None, 
                   action_details=None, success_status=True, error_details=None):
        """Log an action performed by the agent."""
        try:
            database.log_action(
                supabase=self.supabase,
                user_id=user_id,
                action_type=action_type,
                entity_type=entity_type,
                entity_id=entity_id,
                action_details=action_details or {},
                success_status=success_status,
                error_details=error_details
            )
        except Exception as e:
            print(f"!!! AGENT LOGGING ERROR: {e}")
    
    def _clean_response(self, message):
        """Ensure response contains ONLY user-friendly content."""
        if not message:
            return "I'm here to help! How can I assist you?"
        
        # Remove any technical artifacts that might have leaked
        import re
        # Remove JSON-like structures
        message = re.sub(r'\{[^{}]*\}', '', message)
        # Remove array-like structures
        message = re.sub(r'\[[^\[\]]*\]', '', message)
        # Remove technical keywords
        technical_terms = ['json', 'actions', 'status', 'error', 'debug', 'log', 'system']
        for term in technical_terms:
            message = re.sub(f'\\b{term}\\b', '', message, flags=re.IGNORECASE)
        
        # Clean up extra whitespace
        message = ' '.join(message.split())
        
        return message.strip() or "I'm here to help! How can I assist you?"
